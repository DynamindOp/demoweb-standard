import { useEffect, useRef } from "react";
import { HeadContent, Link, Outlet, Scripts, createFileRoute, createRootRouteWithContext, createRouter, lazyRouteComponent, useRouter } from "@tanstack/react-router";
import { jsx, jsxs } from "react/jsx-runtime";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "sonner";
//#region src/components/ui/sonner.tsx
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ jsx(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
//#endregion
//#region src/components/site/CursorTrail.tsx
function CursorTrail() {
	const ref = useRef(null);
	useEffect(() => {
		if (window.matchMedia("(pointer: coarse)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
		const c = ref.current;
		const ctx = c.getContext("2d");
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const resize = () => {
			c.width = innerWidth * dpr;
			c.height = innerHeight * dpr;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
		};
		resize();
		const ps = [];
		let raf = 0;
		const move = (e) => {
			if (e.pointerType !== "mouse") return;
			ps.push({
				x: e.clientX,
				y: e.clientY,
				life: 1,
				r: 2 + Math.random() * 3
			});
			if (ps.length > 60) ps.shift();
			if (!raf) raf = requestAnimationFrame(tick);
		};
		const tick = () => {
			ctx.clearRect(0, 0, innerWidth, innerHeight);
			for (let i = ps.length - 1; i >= 0; i--) {
				const p = ps[i];
				p.life -= .035;
				if (p.life <= 0) {
					ps.splice(i, 1);
					continue;
				}
				ctx.globalAlpha = p.life * .7;
				ctx.fillStyle = "#1486FF";
				ctx.beginPath();
				ctx.arc(p.x, p.y, p.r * p.life, 0, Math.PI * 2);
				ctx.fill();
			}
			raf = ps.length ? requestAnimationFrame(tick) : 0;
		};
		addEventListener("pointermove", move, { passive: true });
		addEventListener("resize", resize);
		return () => {
			removeEventListener("pointermove", move);
			removeEventListener("resize", resize);
			cancelAnimationFrame(raf);
		};
	}, []);
	return /* @__PURE__ */ jsx("canvas", {
		ref,
		"aria-hidden": true,
		className: "pointer-events-none fixed inset-0 z-[60] h-full w-full"
	});
}
//#endregion
//#region src/styles.css?url
var styles_default = "/assets/styles-xkQvCLrm.css";
//#endregion
//#region src/routes/__root.tsx
function NotFoundComponent() {
	return /* @__PURE__ */ jsxs("div", {
		className: "relative flex min-h-screen items-center justify-center overflow-hidden bg-background px-4",
		children: [/* @__PURE__ */ jsx("div", {
			className: "light-orb left-1/2 top-1/2 h-72 w-72 -translate-x-1/2 -translate-y-1/2 opacity-30",
			"aria-hidden": true
		}), /* @__PURE__ */ jsxs("div", {
			className: "relative max-w-md text-center",
			children: [
				/* @__PURE__ */ jsx("h1", {
					className: "font-display text-[9rem] font-bold leading-none text-primary",
					children: "404"
				}),
				/* @__PURE__ */ jsx("h2", {
					className: "mt-4 text-2xl font-bold text-foreground",
					children: "Oops! Page Not Found."
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-3 text-muted-foreground",
					children: "The page you're looking for doesn't exist or may have been moved."
				}),
				/* @__PURE__ */ jsx(Link, {
					to: "/",
					className: "mt-8 inline-flex items-center justify-center rounded-xl bg-primary px-6 py-3 font-bold text-primary-foreground shadow-btn transition-all hover:-translate-y-0.5 hover:bg-primary-hover",
					children: "Back to Home"
				})
			]
		})]
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	return /* @__PURE__ */ jsx("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ jsxs("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ jsx("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ jsx("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ jsx("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ jsx("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$1 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "DemoWebsite" },
			{
				name: "description",
				content: "DemoWebsite — premium business website template."
			},
			{
				property: "og:title",
				content: "DemoWebsite"
			},
			{
				property: "og:description",
				content: "DemoWebsite — premium business website template."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ jsxs("html", {
		lang: "en",
		className: "dark",
		children: [/* @__PURE__ */ jsx("head", { children: /* @__PURE__ */ jsx(HeadContent, {}) }), /* @__PURE__ */ jsxs("body", { children: [children, /* @__PURE__ */ jsx(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$1.useRouteContext();
	return /* @__PURE__ */ jsxs(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ jsx(Outlet, {}),
			/* @__PURE__ */ jsx(CursorTrail, {}),
			/* @__PURE__ */ jsx(Toaster$1, {
				position: "bottom-center",
				theme: "dark"
			})
		]
	});
}
//#endregion
//#region src/routes/index.tsx
var $$splitComponentImporter = () => import("./routes-B6sdVYeI.js");
//#endregion
//#region src/routeTree.gen.ts
var rootRouteChildren = { IndexRoute: createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "DemoWebsite Business — Premium Business Template" },
		{
			name: "description",
			content: "A premium, customizable one-page business website. Describe your edits and make it yours."
		},
		{
			property: "og:title",
			content: "DemoWebsite Business — Premium Business Template"
		},
		{
			property: "og:description",
			content: "A premium, customizable one-page business website. Describe your edits and make it yours."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
}).update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$1
}) };
var routeTree = Route$1._addFileChildren(rootRouteChildren)._addFileTypes();
//#endregion
//#region src/router.tsx
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
