//#region \0tanstack-start-manifest:v
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/PC/OneDrive/Desktop/Resources/projects/DemoWebsite/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DOwoezGf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DOwoezGf.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/PC/OneDrive/Desktop/Resources/projects/DemoWebsite/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-2TWitAph.js"]
	}
} });
//#endregion
export { tsrStartManifest };
