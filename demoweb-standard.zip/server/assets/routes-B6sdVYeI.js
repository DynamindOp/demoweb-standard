import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { toast } from "sonner";
import { ArrowRight, BarChart3, Check, ChevronDown, Copy, Globe, Headphones, Instagram, Layers, Mail, Menu, Rocket, Shield, Sparkles, X, Zap } from "lucide-react";
import * as Dialog from "@radix-ui/react-dialog";
//#region src/components/site/Navbar.tsx
var SECTIONS = [
	{
		id: "home",
		label: "Home"
	},
	{
		id: "services",
		label: "Services"
	},
	{
		id: "features",
		label: "Features"
	},
	{
		id: "faq",
		label: "FAQ"
	},
	{
		id: "contact",
		label: "Contact"
	}
];
var NAV_OFFSET = 72;
/** Which section sits just below the sticky navbar. */
function sectionAt() {
	if (innerHeight + scrollY >= document.documentElement.scrollHeight - 4) return SECTIONS[4].id;
	const line = 96;
	let current = SECTIONS[0].id;
	for (const sec of SECTIONS) {
		const el = document.getElementById(sec.id);
		if (el && el.getBoundingClientRect().top <= line) current = sec.id;
	}
	return current;
}
/** Smooth-scroll so the section starts just below the sticky navbar. Returns the target scroll position. */
function scrollToSection(id) {
	const el = document.getElementById(id);
	if (!el) return null;
	const y = Math.max(0, Math.round(el.getBoundingClientRect().top + scrollY - (id === "home" ? 0 : NAV_OFFSET)));
	scrollTo({
		top: y,
		behavior: "smooth"
	});
	history.replaceState(null, "", `#${id}`);
	return y;
}
function Logo() {
	return /* @__PURE__ */ jsxs("a", {
		href: "#home",
		onClick: (e) => {
			e.preventDefault();
			scrollToSection("home");
		},
		className: "flex items-center gap-2.5",
		children: [/* @__PURE__ */ jsx("span", {
			className: "grid h-9 w-9 place-items-center rounded-lg bg-primary shadow-btn",
			children: /* @__PURE__ */ jsx(Globe, { className: "h-5 w-5 text-primary-foreground" })
		}), /* @__PURE__ */ jsxs("span", {
			className: "font-display text-lg font-bold text-foreground",
			children: ["Demo", /* @__PURE__ */ jsx("span", {
				className: "text-primary",
				children: "Website"
			})]
		})]
	});
}
function Navbar({ onGetStarted }) {
	const [active, setActive] = useState("home");
	const [open, setOpen] = useState(false);
	const [scrolled, setScrolled] = useState(false);
	const tabs = useRef({});
	const [ind, setInd] = useState({
		left: 0,
		width: 0
	});
	const lock = useRef(null);
	useEffect(() => {
		let raf = 0;
		const compute = () => {
			raf = 0;
			setScrolled(scrollY > 10);
			const target = lock.current;
			if (target !== null) {
				const maxY = document.documentElement.scrollHeight - innerHeight;
				if (Math.abs(scrollY - Math.min(target.y, maxY)) > 2) return;
				lock.current = null;
			}
			setActive(sectionAt());
		};
		const onScroll = () => {
			if (!raf) raf = requestAnimationFrame(compute);
		};
		const onScrollEnd = () => {
			const target = lock.current;
			if (target) {
				lock.current = null;
				setActive(target.id);
			} else setActive(sectionAt());
		};
		compute();
		addEventListener("scroll", onScroll, { passive: true });
		addEventListener("scrollend", onScrollEnd);
		addEventListener("resize", onScroll);
		const cancel = () => {
			lock.current = null;
		};
		addEventListener("wheel", cancel, { passive: true });
		addEventListener("touchstart", cancel, { passive: true });
		addEventListener("keydown", cancel);
		return () => {
			removeEventListener("scroll", onScroll);
			removeEventListener("scrollend", onScrollEnd);
			removeEventListener("resize", onScroll);
			removeEventListener("wheel", cancel);
			removeEventListener("touchstart", cancel);
			removeEventListener("keydown", cancel);
			cancelAnimationFrame(raf);
		};
	}, []);
	useLayoutEffect(() => {
		const update = () => {
			const el = tabs.current[active];
			if (el) setInd({
				left: el.offsetLeft,
				width: el.offsetWidth
			});
		};
		update();
		document.fonts?.ready.then(update);
		addEventListener("resize", update);
		return () => removeEventListener("resize", update);
	}, [active]);
	const go = (id) => (e) => {
		e.preventDefault();
		setActive(id);
		setOpen(false);
		const y = scrollToSection(id);
		lock.current = y === null ? null : {
			id,
			y
		};
	};
	return /* @__PURE__ */ jsxs("header", {
		className: `fixed inset-x-0 top-0 z-40 border-b transition-colors duration-300 ${scrolled || open ? "border-border bg-background/85 backdrop-blur-xl" : "border-transparent"}`,
		children: [/* @__PURE__ */ jsxs("nav", {
			className: "mx-auto flex h-[72px] max-w-6xl items-center justify-between px-5",
			children: [
				/* @__PURE__ */ jsx(Logo, {}),
				/* @__PURE__ */ jsxs("div", {
					className: "relative hidden items-center gap-1 md:flex",
					children: [SECTIONS.map((s) => /* @__PURE__ */ jsx("a", {
						href: `#${s.id}`,
						ref: (el) => {
							tabs.current[s.id] = el;
						},
						onClick: go(s.id),
						className: `relative px-4 py-2 text-sm font-semibold transition-colors ${active === s.id ? "text-foreground" : "text-muted-foreground hover:text-foreground"}`,
						children: s.label
					}, s.id)), /* @__PURE__ */ jsx("span", {
						className: "absolute -bottom-1 h-[3px] rounded-full bg-primary shadow-btn transition-all duration-500 ease-[cubic-bezier(.6,0,.2,1)]",
						style: {
							left: ind.left + 12,
							width: Math.max(ind.width - 24, 0)
						}
					})]
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ jsx("button", {
						onClick: onGetStarted,
						className: "rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground shadow-btn transition-all duration-300 hover:-translate-y-0.5 hover:bg-primary-hover active:scale-95 sm:px-5",
						children: "Get Started"
					}), /* @__PURE__ */ jsx("button", {
						onClick: () => setOpen((o) => !o),
						"aria-label": "Toggle menu",
						"aria-expanded": open,
						className: "grid h-10 w-10 place-items-center rounded-xl border border-border text-foreground md:hidden",
						children: open ? /* @__PURE__ */ jsx(X, { className: "h-5 w-5" }) : /* @__PURE__ */ jsx(Menu, { className: "h-5 w-5" })
					})]
				})
			]
		}), /* @__PURE__ */ jsx("div", {
			className: `grid overflow-hidden transition-all duration-300 md:hidden ${open ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`,
			children: /* @__PURE__ */ jsx("div", {
				className: "min-h-0",
				children: /* @__PURE__ */ jsx("div", {
					className: "flex flex-col gap-1 px-5 pb-5",
					children: SECTIONS.map((s) => /* @__PURE__ */ jsxs("a", {
						href: `#${s.id}`,
						onClick: go(s.id),
						className: `flex items-center gap-3 rounded-xl px-4 py-3 font-semibold transition-colors ${active === s.id ? "bg-card text-foreground" : "text-muted-foreground"}`,
						children: [/* @__PURE__ */ jsx("span", { className: `h-2 w-2 rounded-full transition-colors ${active === s.id ? "bg-primary" : "bg-border"}` }), s.label]
					}, s.id))
				})
			})
		})]
	});
}
//#endregion
//#region src/components/site/ContactCards.tsx
var CONTACTS = [{
	label: "Email",
	value: "test@email.com",
	icon: Mail
}, {
	label: "Instagram",
	value: "testuser",
	icon: Instagram
}];
function CopyCard({ label, value, icon: Icon }) {
	const [copied, setCopied] = useState(false);
	const copy = async () => {
		try {
			await navigator.clipboard.writeText(value);
		} catch {
			const t = document.createElement("textarea");
			t.value = value;
			document.body.appendChild(t);
			t.select();
			document.execCommand("copy");
			t.remove();
		}
		setCopied(true);
		toast.success("Copied to clipboard!", { description: value });
		setTimeout(() => setCopied(false), 1800);
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "w-full",
		children: [/* @__PURE__ */ jsx("p", {
			className: "mb-2 text-sm font-semibold text-muted-foreground",
			children: label
		}), /* @__PURE__ */ jsxs("div", {
			className: "glow-card flex items-center gap-3 rounded-xl border border-border bg-card p-3 pl-4",
			children: [
				/* @__PURE__ */ jsx(Icon, { className: "h-5 w-5 shrink-0 text-primary" }),
				/* @__PURE__ */ jsx("span", {
					className: "flex-1 truncate font-medium",
					children: value
				}),
				/* @__PURE__ */ jsx("button", {
					onClick: copy,
					"aria-label": `Copy ${label}`,
					className: "grid h-10 w-10 place-items-center rounded-lg border border-border bg-surface text-primary transition-all duration-300 hover:scale-110 hover:rotate-[-6deg] hover:border-primary hover:bg-primary hover:text-primary-foreground active:scale-95",
					children: copied ? /* @__PURE__ */ jsx(Check, { className: "h-4 w-4" }) : /* @__PURE__ */ jsx(Copy, { className: "h-4 w-4" })
				})
			]
		})]
	});
}
function ContactCards() {
	return /* @__PURE__ */ jsx("div", {
		className: "grid w-full gap-5 sm:grid-cols-2",
		children: CONTACTS.map((c) => /* @__PURE__ */ jsx(CopyCard, { ...c }, c.label))
	});
}
//#endregion
//#region src/components/site/ContactModal.tsx
function ContactModal({ open, onOpenChange }) {
	return /* @__PURE__ */ jsx(Dialog.Root, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ jsxs(Dialog.Portal, { children: [/* @__PURE__ */ jsx(Dialog.Overlay, { className: "fixed inset-0 z-50 bg-background/80 backdrop-blur-sm data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=closed]:animate-out data-[state=closed]:fade-out-0" }), /* @__PURE__ */ jsxs(Dialog.Content, {
			className: "fixed left-1/2 top-1/2 z-50 w-[calc(100%-2rem)] max-w-xl -translate-x-1/2 -translate-y-1/2 rounded-2xl border border-border bg-surface p-6 shadow-btn sm:p-8 data-[state=open]:animate-in data-[state=open]:fade-in-0 data-[state=open]:zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 duration-300",
			children: [
				/* @__PURE__ */ jsxs(Dialog.Title, {
					className: "font-display text-2xl font-bold sm:text-3xl",
					children: ["Contact Us ", /* @__PURE__ */ jsx("span", {
						className: "text-primary",
						children: "Now!"
					})]
				}),
				/* @__PURE__ */ jsx(Dialog.Description, {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Reach out through any channel below — we usually reply within a day."
				}),
				/* @__PURE__ */ jsx("div", {
					className: "mt-6",
					children: /* @__PURE__ */ jsx(ContactCards, {})
				}),
				/* @__PURE__ */ jsx(Dialog.Close, {
					"aria-label": "Close",
					className: "absolute right-4 top-4 grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:border-primary hover:text-foreground",
					children: /* @__PURE__ */ jsx(X, { className: "h-4 w-4" })
				})
			]
		})] })
	});
}
//#endregion
//#region src/components/site/Reveal.tsx
function Reveal({ children, delay = 0, className = "" }) {
	const ref = useRef(null);
	useEffect(() => {
		const el = ref.current;
		const io = new IntersectionObserver(([e]) => {
			if (e?.isIntersecting) {
				el.classList.add("is-visible");
				io.disconnect();
			}
		}, { threshold: .15 });
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ jsx("div", {
		ref,
		className: `reveal ${className}`,
		style: { transitionDelay: `${delay}ms` },
		children
	});
}
function SectionHeading({ eyebrow, title }) {
	return /* @__PURE__ */ jsxs(Reveal, {
		className: "mx-auto mb-14 max-w-2xl text-center",
		children: [/* @__PURE__ */ jsx("p", {
			className: "mb-3 text-sm font-medium text-primary",
			children: eyebrow
		}), /* @__PURE__ */ jsx("h2", {
			className: "text-3xl font-bold sm:text-5xl",
			children: title
		})]
	});
}
//#endregion
//#region src/routes/index.tsx?tsr-split=component
var FEATURES = [
	{
		icon: Zap,
		title: "Feature #1"
	},
	{
		icon: Shield,
		title: "Feature #2"
	},
	{
		icon: Rocket,
		title: "Feature #3"
	},
	{
		icon: BarChart3,
		title: "Feature #4"
	},
	{
		icon: Layers,
		title: "Feature #5"
	},
	{
		icon: Headphones,
		title: "Feature #6"
	}
];
function Index() {
	const [modal, setModal] = useState(false);
	const [faq, setFaq] = useState(null);
	const openModal = () => setModal(true);
	return /* @__PURE__ */ jsxs("div", {
		className: "overflow-x-hidden",
		children: [
			/* @__PURE__ */ jsx(Navbar, { onGetStarted: openModal }),
			/* @__PURE__ */ jsx(ContactModal, {
				open: modal,
				onOpenChange: setModal
			}),
			/* @__PURE__ */ jsxs("section", {
				id: "home",
				className: "relative flex min-h-screen items-center justify-center px-5 pt-24 pb-16",
				children: [/* @__PURE__ */ jsx("div", {
					className: "light-orb left-1/2 top-1/3 h-72 w-72 -translate-x-1/2 opacity-25 sm:h-96 sm:w-96",
					"aria-hidden": true
				}), /* @__PURE__ */ jsxs("div", {
					className: "relative mx-auto max-w-4xl text-center",
					children: [
						/* @__PURE__ */ jsx(Reveal, { children: /* @__PURE__ */ jsxs("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-border bg-card/70 py-1.5 pl-1.5 pr-4 text-sm font-semibold backdrop-blur",
							children: [/* @__PURE__ */ jsx("span", {
								className: "grid h-6 w-6 place-items-center rounded-full bg-primary",
								children: /* @__PURE__ */ jsx(Sparkles, { className: "h-3.5 w-3.5 text-primary-foreground" })
							}), "Business Category"]
						}) }),
						/* @__PURE__ */ jsx(Reveal, {
							delay: 120,
							children: /* @__PURE__ */ jsxs("h1", {
								className: "mt-8 text-5xl font-bold leading-[1.05] sm:text-7xl lg:text-8xl",
								children: [
									"Demo",
									/* @__PURE__ */ jsx("span", {
										className: "text-primary",
										children: "Website"
									}),
									" Business"
								]
							})
						}),
						/* @__PURE__ */ jsx(Reveal, {
							delay: 240,
							children: /* @__PURE__ */ jsx("p", {
								className: "mx-auto mt-6 max-w-2xl text-lg text-muted-foreground sm:text-xl",
								children: "This is a DemoBusiness website, Please Describe the edits and make it Yours!"
							})
						}),
						/* @__PURE__ */ jsxs(Reveal, {
							delay: 360,
							className: "mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row",
							children: [/* @__PURE__ */ jsxs("button", {
								onClick: openModal,
								className: "group inline-flex items-center gap-2 rounded-xl bg-primary px-7 py-3.5 font-bold text-primary-foreground shadow-btn transition-all duration-300 hover:-translate-y-0.5 hover:bg-primary-hover active:scale-95",
								children: ["Get Started ", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
							}), /* @__PURE__ */ jsx("a", {
								href: "#services",
								onClick: (e) => {
									e.preventDefault();
									scrollToSection("services");
								},
								className: "rounded-xl border border-border bg-card/60 px-7 py-3.5 font-bold transition-all duration-300 hover:border-primary",
								children: "Explore Services"
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ jsx("section", {
				id: "services",
				className: "bg-surface px-5 py-28",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-6xl",
					children: [/* @__PURE__ */ jsx(SectionHeading, {
						eyebrow: "Services",
						title: "What We Provide"
					}), /* @__PURE__ */ jsx("div", {
						className: "grid gap-6 md:grid-cols-3 md:items-stretch",
						children: [
							1,
							2,
							3
						].map((n, i) => {
							const popular = n === 2;
							return /* @__PURE__ */ jsx(Reveal, {
								delay: i * 120,
								className: "h-full",
								children: /* @__PURE__ */ jsxs("div", {
									tabIndex: 0,
									className: `glow-card relative flex h-full flex-col rounded-2xl border p-8 outline-none ${popular ? "border-primary bg-card md:-translate-y-3" : "border-border bg-card"}`,
									children: [
										popular && /* @__PURE__ */ jsx("span", {
											className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary px-3 py-1 text-xs font-bold uppercase tracking-wider text-primary-foreground",
											children: "Popular"
										}),
										/* @__PURE__ */ jsxs("h3", {
											className: "text-xl font-bold",
											children: ["Service #", n]
										}),
										/* @__PURE__ */ jsx("p", {
											className: "mt-2 text-sm text-muted-foreground",
											children: "A short description of what this service includes."
										}),
										/* @__PURE__ */ jsx("p", {
											className: "mt-8 font-display text-5xl font-bold",
											children: "$--"
										}),
										/* @__PURE__ */ jsx("ul", {
											className: "mt-8 space-y-3 text-sm text-muted-foreground",
											children: [
												"Benefit #1",
												"Benefit #2",
												"Benefit #3",
												"Benefit #4",
												"Benefit #5"
											].map((b) => /* @__PURE__ */ jsxs("li", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ jsx(Check, { className: "h-4 w-4 text-primary" }), b]
											}, b))
										}),
										/* @__PURE__ */ jsxs("button", {
											onClick: openModal,
											className: `group mt-10 inline-flex items-center justify-center gap-2 rounded-xl px-5 py-3 font-bold transition-all duration-300 active:scale-95 ${popular ? "bg-primary text-primary-foreground shadow-btn hover:bg-primary-hover" : "border border-border bg-surface hover:border-primary hover:bg-primary hover:text-primary-foreground"}`,
											children: ["Buy Now ", /* @__PURE__ */ jsx(ArrowRight, { className: "h-4 w-4 transition-transform group-hover:translate-x-1" })]
										})
									]
								})
							}, n);
						})
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				id: "features",
				className: "relative px-5 py-28",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-6xl",
					children: [/* @__PURE__ */ jsx(SectionHeading, {
						eyebrow: "Features",
						title: "Our Features"
					}), /* @__PURE__ */ jsx("div", {
						className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
						children: FEATURES.map(({ icon: Icon, title }, i) => /* @__PURE__ */ jsx(Reveal, {
							delay: i % 3 * 100,
							children: /* @__PURE__ */ jsxs("div", {
								tabIndex: 0,
								className: "glow-card group h-full rounded-2xl border border-border bg-card p-7 outline-none",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "grid h-12 w-12 place-items-center rounded-xl border border-border bg-surface text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground",
										children: /* @__PURE__ */ jsx(Icon, { className: "h-6 w-6" })
									}),
									/* @__PURE__ */ jsx("h3", {
										className: "mt-6 text-lg font-bold",
										children: title
									}),
									/* @__PURE__ */ jsx("p", {
										className: "mt-2 text-sm leading-relaxed text-muted-foreground",
										children: "Placeholder description explaining how this feature helps your customers."
									})
								]
							})
						}, title))
					})]
				})
			}),
			/* @__PURE__ */ jsx("section", {
				id: "faq",
				className: "bg-surface px-5 py-28",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto max-w-3xl",
					children: [/* @__PURE__ */ jsx(SectionHeading, {
						eyebrow: "FAQ",
						title: "Frequently Asked Questions"
					}), /* @__PURE__ */ jsx("div", {
						className: "space-y-4",
						children: [
							1,
							2,
							3,
							4,
							5
						].map((n, i) => {
							const isOpen = faq === n;
							return /* @__PURE__ */ jsx(Reveal, {
								delay: i * 70,
								children: /* @__PURE__ */ jsxs("div", {
									className: `rounded-2xl border bg-card transition-all duration-300 ${isOpen ? "border-primary shadow-btn" : "border-border hover:border-primary"}`,
									children: [/* @__PURE__ */ jsxs("button", {
										onClick: () => setFaq(isOpen ? null : n),
										"aria-expanded": isOpen,
										className: "flex w-full items-center justify-between gap-4 p-6 text-left font-semibold",
										children: [/* @__PURE__ */ jsxs("span", {
											className: isOpen ? "text-primary" : "",
											children: ["Question #", n]
										}), /* @__PURE__ */ jsx(ChevronDown, { className: `h-5 w-5 shrink-0 text-primary transition-transform duration-300 ${isOpen ? "rotate-180" : ""}` })]
									}), /* @__PURE__ */ jsx("div", {
										className: `grid transition-all duration-300 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`,
										children: /* @__PURE__ */ jsx("div", {
											className: "min-h-0 overflow-hidden",
											children: /* @__PURE__ */ jsxs("p", {
												className: "px-6 pb-6 text-muted-foreground",
												children: ["Answer #", n]
											})
										})
									})]
								})
							}, n);
						})
					})]
				})
			}),
			/* @__PURE__ */ jsxs("section", {
				id: "contact",
				className: "relative px-5 py-28",
				children: [/* @__PURE__ */ jsx("div", {
					className: "light-orb left-1/2 top-1/2 h-64 w-64 -translate-x-1/2 -translate-y-1/2 opacity-20",
					"aria-hidden": true
				}), /* @__PURE__ */ jsxs("div", {
					className: "relative mx-auto max-w-2xl",
					children: [/* @__PURE__ */ jsx(SectionHeading, {
						eyebrow: "Get in touch",
						title: "Contact Us"
					}), /* @__PURE__ */ jsx(Reveal, { children: /* @__PURE__ */ jsx(ContactCards, {}) })]
				})]
			}),
			/* @__PURE__ */ jsx("footer", {
				className: "border-t border-border px-5 py-10",
				children: /* @__PURE__ */ jsxs("div", {
					className: "mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 sm:flex-row",
					children: [/* @__PURE__ */ jsx(Logo, {}), /* @__PURE__ */ jsxs("p", {
						className: "text-sm text-muted-foreground",
						children: [
							"© ",
							(/* @__PURE__ */ new Date()).getFullYear(),
							" DemoWebsite. All rights reserved."
						]
					})]
				})
			})
		]
	});
}
//#endregion
export { Index as component };
